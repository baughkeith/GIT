package service;

import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import jpm.model.Direction;
import jpm.model.Stock;
import jpm.model.StockSymbol;
import jpm.model.StockType;
import jpm.model.Trade;
import jpm.service.StockPriceCalculator;
import jpm.storage.TradeCache;

import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for the stock price calculations.
 * @author kbaugh
 *
 */
public class StockPriceCalculatorTest {
	private StockPriceCalculator stockPriceCalculator;
	private TradeCache tradeCache;
	private List<Stock> stockList;

	/**
	 * Initialize the trade cache with test trades.
	 */
	@Before
	public void setUp() {
		tradeCache = new TradeCache();
		//--------------
		// Sample trades
		//--------------
		tradeCache.addTrade(new Trade("1", StockSymbol.TEA, 
							System.currentTimeMillis(), new BigDecimal("50"), 
							Direction.BUY, new BigDecimal("1.1")));
		tradeCache.addTrade(new Trade("2", StockSymbol.GIN, 
							System.currentTimeMillis(), new BigDecimal("150"), 
							Direction.BUY, new BigDecimal("1.5")));
		tradeCache.addTrade(new Trade("3", StockSymbol.POP, 
							System.currentTimeMillis(), new BigDecimal("250"), 
							Direction.BUY, new BigDecimal("2.1")));
		tradeCache.addTrade(new Trade("4", StockSymbol.ALE, 
							System.currentTimeMillis(), new BigDecimal("10"), 
							Direction.BUY, new BigDecimal("4.1")));
		tradeCache.addTrade(new Trade("5", StockSymbol.JOE, 
							System.currentTimeMillis(), new BigDecimal("60"), 
							Direction.BUY, new BigDecimal("2.1")));
		tradeCache.addTrade(new Trade("6", StockSymbol.TEA, 
							System.currentTimeMillis(), new BigDecimal("30"), 
							Direction.BUY, new BigDecimal("5.1")));
		//--------------
		// Sample stocks
		//--------------
		stockList = new ArrayList<Stock>();
		stockList.add(new Stock(StockSymbol.TEA, StockType.COMMON,	
								BigDecimal.ZERO, null, new BigDecimal(100)));

		stockList.add(new Stock(StockSymbol.POP, StockType.COMMON, 
								new BigDecimal(8), null, new BigDecimal(100)));

		stockList.add(new Stock(StockSymbol.ALE, StockType.COMMON, 
								new BigDecimal(23), null, new BigDecimal(60)));

		stockList.add(new Stock(StockSymbol.GIN, StockType.PREFERRED,
								new BigDecimal(8), new BigDecimal(2), new BigDecimal(100)));

		stockList.add(new Stock(StockSymbol.JOE, StockType.COMMON, 
								new BigDecimal(13), null, new BigDecimal(250)));
		//-----------------
		// Create the cache
		//-----------------
		stockPriceCalculator = new StockPriceCalculator(tradeCache);
	}

	/**
	 * Test the dividend yield calculation.
	 */
	@Test
	public void testCalculateDividendYield() {
		Stock stock = stockList.get(0);
		BigDecimal dividendYield = stockPriceCalculator
										.calculateDividendYield(stock);
		assertTrue(areEqual(BigDecimal.ZERO, dividendYield));
		
	    stock = stockList.get(1);
		dividendYield = stockPriceCalculator.calculateDividendYield(stock);
		assertTrue(areEqual(new BigDecimal(4), dividendYield));
		
		stock = stockList.get(3);
		dividendYield = stockPriceCalculator.calculateDividendYield(stock);
		assertTrue(areEqual(new BigDecimal(1), dividendYield));
	}

	/**
	 * Tests the p/e ratio calculation.
	 */
	@Test
	public void testCalculatePERatio() {
		Stock stock = stockList.get(0);
		BigDecimal peRatio = stockPriceCalculator.calculatePERatio(stock);
		assertTrue(areEqual(BigDecimal.ZERO, peRatio));

		stock = stockList.get(1);
		peRatio = stockPriceCalculator.calculatePERatio(stock);
		assertTrue(areEqual(new BigDecimal("0.5"), peRatio));
		
		stock = stockList.get(2);
		peRatio = stockPriceCalculator.calculatePERatio(stock);
		assertTrue(areEqual(new BigDecimal("0.7"), peRatio));
	}

	/**
	 * Test the stock price.
	 */
	@Test
	public void testCalculateStockPrice() {
		BigDecimal stockPrice = stockPriceCalculator.calculateStockPrice(stockList
				.get(0).getStockSymbol(), 15, TimeUnit.MINUTES);
		assertTrue(areEqual(new BigDecimal("2.6"), stockPrice));
	}

	/**
	 * Test the geometric mean.
	 */
	@Test
	public void testCalculateGeometricMean() {
		BigDecimal geometricMean = stockPriceCalculator
				.calculateGeometricMean(stockList);
		assertTrue(areEqual(new BigDecimal("2.342380"), geometricMean));
	}

	/**
	 * Determines whether two <code>BigDecimal</code> numbers are equal. This
	 * method ignores scale differences.
	 * 
	 * @param o1
	 *            the first value.
	 * @param o2
	 *            the second value.
	 * @return <code>true</code> if the numbers are equal, <code>false</code> if
	 *         not.
	 */
	private boolean areEqual(BigDecimal o1, BigDecimal o2) {
		if (o1 == null && o2 == null) {
			return true;
		}
		return o1 != null && o2 != null && o1.compareTo(o2) == 0;
	}

}

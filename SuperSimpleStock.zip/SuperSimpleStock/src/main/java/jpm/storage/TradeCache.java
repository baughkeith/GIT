package jpm.storage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jpm.model.StockSymbol;
import jpm.model.Trade;

/**
 * Class to hold trades held in memory.
 * @author kbaugh
 *
 */
public class TradeCache {
	
	/**
	 * Trade cache container.
	 */
	private final Map<String, Trade> tradeIdToTradeMap = new HashMap<String, Trade>();

	/**
	 * Default class constructor.
	 */
	public TradeCache() {
	}

	/**
	 * Adds a trade to the cache.
	 * @param trade
	 */
	public void addTrade(Trade trade) {
		tradeIdToTradeMap.put(trade.getTradeId(), trade);
	}

	/**
	 * Gets and existing trade with the supplied trade Id, or null if this cache contains 
	 * no mapping for the key
	 * @param tradeId
	 * @return trade.
	 */
	public Trade getTrade(String tradeId) {
		return tradeIdToTradeMap.get(tradeId);
	}

	/**
	 * Gets all existing trades.
	 * @return List<Trade>
	 */
	public List<Trade> getAllTrades() {
		return new ArrayList<Trade>(tradeIdToTradeMap.values());
	}

	/**
	 * Gets all existing trades 
	 * @param stockSymbol
	 * @param timeInMillis
	 * @return
	 */
	public List<Trade> getTrades(StockSymbol stockSymbol, long timeInMillis) {
		List<Trade> filteredTrades = new ArrayList<Trade>();
		if (stockSymbol != null) {
			for (Trade trade : tradeIdToTradeMap.values()) {
				long tradeTimestamp = trade.getTimestamp();
				long executedWithin = System.currentTimeMillis() - tradeTimestamp;
				if (stockSymbol.equals(trade.getStockSymbol()) &&
						executedWithin <= timeInMillis) {
					filteredTrades.add(trade);
				}
			}
		}
		return filteredTrades;
	}
}

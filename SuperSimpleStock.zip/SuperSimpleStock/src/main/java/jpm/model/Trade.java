package jpm.model;

import java.math.BigDecimal;

/**
 * Class to represent a trade on the exchange.
 * This class is immutable.
 * @author kbaugh
 *
 */
public class Trade {
	private final String tradeId;
	private final long timestamp;
	private final StockSymbol stockSymbol;
	private final BigDecimal quantity;
	private final Direction direction;
	private final BigDecimal price;

	/**
	 * Class constructor.
	 * @param tradeId
	 * @param stockSymbol
	 * @param timestamp
	 * @param quantity
	 * @param direction
	 * @param price
	 */
	public Trade(String tradeId, StockSymbol stockSymbol, long timestamp, 
			BigDecimal quantity, Direction direction, BigDecimal price) {
		this.tradeId = tradeId;
		this.stockSymbol = stockSymbol;
		this.timestamp = timestamp;
		this.quantity = quantity;
		this.direction = direction;
		this.price = price;
	}

	/**
	 * Getter for the trade id value.
	 * @return tradeId.
	 */
	public String getTradeId() {
		return tradeId;
	}
	
	/**
	 * Getter for the stock symbol value.
	 * @return stockSymbol.
	 */
	public StockSymbol getStockSymbol() {
		return stockSymbol;
	}

	/**
	 * Getter for the time stamp value.
	 * @return timestamp.
	 */
	public long getTimestamp() {
		return timestamp;
	}

	/**
	 * Getter for the quantity value.
	 * @return quantity.
	 */
	public BigDecimal getQuantity() {
		return quantity;
	}

	/**
	 * Getter for the direction value.
	 * @return direction.
	 */
	public Direction getDirection() {
		return direction;
	}

	/**
	 * Getter for the trade id.
	 * @return tradeId.
	 */
	public BigDecimal getPrice() {
		return price;
	}
}

package jpm.model;

/**
 * Stock type traded on the Global Beverage Corporation to differentiate 
 * dividend yield calculations.
 * 
 * @author kbaugh
 *
 */
public enum StockType {
	/**
	 * Common stock type.
	 */
	COMMON,
	/**
	 * Preferred stock type.
	 */
	PREFERRED
}

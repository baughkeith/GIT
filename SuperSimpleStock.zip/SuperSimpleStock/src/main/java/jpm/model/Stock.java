package jpm.model;

import java.math.BigDecimal;

/**
 * Class to represent a stock traded on the Global Beverage Corporation
 * Exchange. This class is immutable.
 * 
 * @author kbaugh
 * 
 */
public class Stock {
	private final StockSymbol stockSymbol;
	private final StockType stockType;
	private final BigDecimal lastDividend;
	private final BigDecimal fixedDividend;
	private final BigDecimal parValue;

	/**
	 * Stock class constructor having a fixed dividend.
	 * 
	 * @param stockSymbol symbol for the traded stock.
	 * @param stockType
	 * @param lastDividend
	 * @param fixedDividend
	 * @param parValue the stated value or face value.
	 */
	public Stock(StockSymbol stockSymbol, StockType stockType, 
													BigDecimal lastDividend,
													BigDecimal fixedDividend,
													BigDecimal parValue) {
		this.stockSymbol = stockSymbol;
		this.stockType = stockType;
		this.lastDividend = lastDividend;
		this.fixedDividend = fixedDividend;
		this.parValue = parValue;
	}
	
	/**
	 * Stock class constructor having no fixed dividend .
	 * @param stockSymbol symbol for the traded stock.
	 * @param stockType 
	 * @param lastDividend
	 * @param parValue
	 */
	public Stock(StockSymbol stockSymbol, StockType stockType,
												BigDecimal lastDividend, 
												BigDecimal parValue) {
		this(stockSymbol, stockType, parValue, BigDecimal.ZERO, parValue);
	}
	
	/**
	 * Getter for the stockSymbol value.
	 * @return stockSymbol
	 */
	public StockSymbol getStockSymbol() {
		return stockSymbol;
	}
	
	/**
	 * Getter for the stockType value.
	 * @return stockType
	 */
	public StockType getStockType() {
		return stockType;
	}

	/**
	 * Getter for the lastDividend value.
	 * @return lastDividend
	 */
	public BigDecimal getLastDividend() {
		return lastDividend;
	}

	/**
	 * Getter for the fixedDividend value.
	 * @return fixedDividend
	 */
	public BigDecimal getFixedDividend() {
		return fixedDividend;
	}

	/**
	 * Getter for the parValue value.
	 * @return parValue
	 */
	public BigDecimal getParValue() {
		return parValue;
	}
}

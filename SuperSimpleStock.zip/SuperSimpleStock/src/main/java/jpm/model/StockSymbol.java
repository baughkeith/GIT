package jpm.model;
/**
 * An enum that represents stock symbols on the Global Beverage Corporation 
 * Exchange.
 * @author kbaugh
 */
public enum StockSymbol {
	/**
	 * Indicates the TEA stock symbol.
	 */
	TEA,
	/**
	 * Indicates the POP stock symbol.
	 */
	POP,
	/**
	 * Indicates the ALE stock symbol.
	 */
	ALE,
	/**
	 * Indicates the GIN stock symbol.
	 */
	GIN,
	/**
	 * Indicates the JOE stock symbol.
	 */
	JOE
}

package jpm.model;

/**
 * Direction of the trading from the banks perspective.
 * @author kbaugh
 *
 */
public enum Direction {
	/**
	 * Indicates BUY stock trading.
	 */
	BUY,
	/**
	 * Indicates BUY stock trading.
	 */
	SELL
}

package jpm.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.concurrent.TimeUnit;

import jpm.model.Stock;
import jpm.model.StockSymbol;
import jpm.model.Trade;
import jpm.storage.TradeCache;

/**
 * Class to calculate for a given stock its price,
 * dividend yield, P/E ratio and mean
 * @author kbaugh
 *
 */
public class StockPriceCalculator {

	/**
	 * Temporary trade cache.
	 */
	private final TradeCache tradeCache;

	/**
	 * Class constructor
	 * @param tradeCache cache to hold trades
	 */
	public StockPriceCalculator(TradeCache tradeCache) {
		this.tradeCache = tradeCache;
	}

	/**
	 * Calculates the stock price.
	 * @param stockSymbol
	 * @param time
	 * @param timeUnit
	 * @return BigDecimal stock price
	 */
	public BigDecimal calculateStockPrice(StockSymbol stockSymbol, long time,	
														TimeUnit timeUnit) {
		long timeInMillis = timeUnit.toMillis(time);
		List<Trade> filteredTrades = tradeCache.getTrades(stockSymbol,
																timeInMillis);
		BigDecimal totalQuantity = BigDecimal.ZERO;
		BigDecimal totalAmount = BigDecimal.ZERO;
		for (Trade trade : filteredTrades) {
			totalQuantity = totalQuantity.add(trade.getQuantity());
			totalAmount = totalAmount.add(trade.getPrice().multiply(
														trade.getQuantity()));
		}
		return isZero(totalQuantity) ? BigDecimal.ZERO : totalAmount.divide(
				totalQuantity, RoundingMode.HALF_EVEN);
	}

	/**
	 * Calculates a stocks dividend yield.
	 * @param stock
	 * @return BigDecimal stocks dividend yield
	 */
	public BigDecimal calculateDividendYield(Stock stock) {
		if (stock == null) {
			return BigDecimal.ZERO;
		}
		final BigDecimal dividendYield;
		BigDecimal stockPrice = calculateStockPrice(stock.getStockSymbol(), 15,
															TimeUnit.MINUTES);
		switch (stock.getStockType()) {
		case COMMON:
			dividendYield = calculateCommonDividendYield(
										stock.getLastDividend(), stockPrice);
			break;
		case PREFERRED:
			dividendYield = calculatePreferredDividendYield(
					stock.getFixedDividend(), stock.getParValue(), stockPrice);
			break;
		default:
			dividendYield = BigDecimal.ZERO;
			break;
		}
		return dividendYield;
	}
	
	/**
	 * Calculates the preferred stocks dividend yield.
	 * @param fixedDividend
	 * @param parValue
	 * @param stockPrice
	 * @return BigDecimal preferred dividend yield
	 */
	private BigDecimal calculatePreferredDividendYield(
			BigDecimal fixedDividend, BigDecimal parValue, BigDecimal stockPrice) {
		if (isZero(stockPrice)) {
			return BigDecimal.ZERO;
		}

		BigDecimal fixedDividendParValue = fixedDividend.multiply(parValue)
				.divide(new BigDecimal(100), RoundingMode.HALF_EVEN);

		return fixedDividendParValue.divide(stockPrice, RoundingMode.HALF_EVEN);
	}

	/**
	 * Calculates a stocks P/E ratio.
	 * @param stock
	 * @return BigDecimal stocks P/E ratio.
	 */
	public BigDecimal calculatePERatio(Stock stock) {
		BigDecimal stockPrice = calculateStockPrice(
								stock.getStockSymbol(), 15,	TimeUnit.MINUTES);
		BigDecimal dividend = calculateDividendYield(stock);
		return isZero(dividend) ? BigDecimal.ZERO : 
						stockPrice.divide(dividend, RoundingMode.HALF_EVEN);	
	}

	/**
	 * Calculates the geometric mean for all stocks.
	 * @param allStocks list of all stocks.
	 * @return BigDecimal geometric mean.
	 */
	public BigDecimal calculateGeometricMean(List<Stock> allStocks) {
		if (allStocks == null || allStocks.isEmpty()) {
			return BigDecimal.ZERO;
		}
		BigDecimal totalAmount = null;
		int numberOfNonEmptyStocks = 0;
		for (Stock stock : allStocks) {
			BigDecimal stockPrice = calculateStockPrice(stock.getStockSymbol(),
					15, TimeUnit.MINUTES);
			if (!isZero(stockPrice)) {
				if (totalAmount == null) {
					totalAmount = BigDecimal.ONE;
				}
				totalAmount = totalAmount.multiply(stockPrice);
				numberOfNonEmptyStocks++;
			}
		}

		BigDecimal geometricMean = BigDecimal.ZERO;
		if (totalAmount != null && numberOfNonEmptyStocks > 0) {
			double exponent = 1.0 / numberOfNonEmptyStocks;
			geometricMean = new BigDecimal(Math.pow(totalAmount.doubleValue(),
					exponent));
			geometricMean = geometricMean.setScale(6, RoundingMode.HALF_EVEN);
		}
		return geometricMean;
	}

	/**
	 * Calculates the common dividend yield.
	 * @param lastDividend
	 * @param stockPrice
	 * @return BigDecimal
	 */
	private BigDecimal calculateCommonDividendYield(BigDecimal lastDividend,
													BigDecimal stockPrice) {		
		return isZero(stockPrice) ? BigDecimal.ZERO 
				: lastDividend.divide(stockPrice, RoundingMode.HALF_EVEN);
		
	}
	
	/**
	 * Determines whether a <code>BigDecimal</code> is zero.
	 * 
	 * @param value the value to compare.
	 * @return <code>true</code> if the value is zero, <code>false</code> if
	 * not.
	 */
	private boolean isZero(BigDecimal value) {
		return value != null && value.compareTo(BigDecimal.ZERO) == 0;
	}
}
